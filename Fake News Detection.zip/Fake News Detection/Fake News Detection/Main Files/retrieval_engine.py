# -*- coding: utf-8 -*-
# %% [markdown]
# # Retrieval Engine
#
# Google News RSS retrieval and paragraph-level evidence ranking.
#
# Pipeline:
#
# Query -> Google News RSS -> Google URL decode -> semantic article ranking ->
# smart downloader -> paragraph extraction -> paragraph ranking -> evidence
# document.

# %% [markdown]
# # Imports

# %%
import re
import urllib.parse
from collections import Counter
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

import feedparser
from newspaper import Article
from sentence_transformers import SentenceTransformer, util

try:
    import trafilatura
except Exception:
    trafilatura = None

try:
    from googlenewsdecoder import gnewsdecoder
except Exception:
    gnewsdecoder = None


# %% [markdown]
# # Configuration
#
# Default semantic model and source credibility weights.

# %%
DEFAULT_SEMANTIC_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


SOURCE_CREDIBILITY = {
    "reuters": 1.00,
    "associated press": 1.00,
    "ap": 1.00,
    "bbc": 0.98,
    "bloomberg": 0.96,
    "cnbc": 0.95,
    "techcrunch": 0.92,
    "business insider": 0.90,
    "insider": 0.90,
    "the verge": 0.88,
    "wired": 0.88,
    "ars technica": 0.87,
    "forbes": 0.84,
    "fortune": 0.84,
    "pulse": 0.75,
    "pulse 2.0": 0.75,
    "memeburn": 0.65,
}


SEARCH_STOPWORDS = {
    "about",
    "after",
    "again",
    "against",
    "also",
    "because",
    "before",
    "being",
    "between",
    "could",
    "during",
    "from",
    "have",
    "into",
    "more",
    "news",
    "over",
    "said",
    "says",
    "than",
    "that",
    "their",
    "there",
    "this",
    "through",
    "under",
    "were",
    "what",
    "when",
    "where",
    "which",
    "while",
    "with",
    "would",
}


# %% [markdown]
# # Retrieval Config
#
# Controls the number of RSS results, ranked articles, downloaded sources, and
# selected evidence paragraphs.

# %%
@dataclass
class RetrievalConfig:
    rss_results: int = 10
    ranked_articles: int = 6
    max_downloads: int = 5
    evidence_paragraphs: int = 5
    min_article_chars: int = 500
    min_paragraph_chars: int = 80
    max_paragraph_chars: int = 1500
    max_paragraph_pool: int = 120
    query_keyword_count: int = 12


_SEMANTIC_MODEL = None


# %% [markdown]
# # Load MiniLM
#
# Loads the SentenceTransformer model once and reuses it across retrieval calls.

# %%
def get_semantic_model(model_name: str = DEFAULT_SEMANTIC_MODEL):
    global _SEMANTIC_MODEL

    if _SEMANTIC_MODEL is None:
        _SEMANTIC_MODEL = SentenceTransformer(model_name)

    return _SEMANTIC_MODEL


# %% [markdown]
# # Search Query Builder
#
# Builds a richer Google News query from the claim, headline, and article text.

# %%
def extract_search_keywords(text: str, top_n: int = 12) -> List[str]:
    words = re.findall(r"[A-Za-z][A-Za-z0-9'-]{2,}", text or "")
    normalized = [
        word.lower().strip("'")
        for word in words
        if word.lower() not in SEARCH_STOPWORDS
    ]
    counts = Counter(normalized)

    return [word for word, _ in counts.most_common(top_n)]


def build_retrieval_query(
    claim: str,
    headline: str = "",
    article_text: str = "",
    keyword_count: int = 12,
) -> str:
    base_parts = []

    if claim:
        base_parts.append(claim)

    if headline and headline.lower() not in " ".join(base_parts).lower():
        base_parts.append(headline)

    keywords = extract_search_keywords(
        " ".join([headline or "", article_text or ""]),
        top_n=keyword_count,
    )

    query = " ".join(base_parts + keywords)
    query = " ".join(query.split())

    return query[:300]


# %% [markdown]
# # Step 1 - Google News RSS Retriever
#
# Searches Google News RSS for candidate evidence articles.

# %%
def google_news(query: str, max_results: int = 10) -> List[Dict[str, str]]:
    encoded = urllib.parse.quote(query)

    rss = (
        "https://news.google.com/rss/search?"
        f"q={encoded}"
        "&hl=en-US"
        "&gl=US"
        "&ceid=US:en"
    )

    feed = feedparser.parse(rss)
    results = []

    for item in feed.entries[:max_results]:
        source = ""

        if hasattr(item, "source") and isinstance(item.source, dict):
            source = item.source.get("title", "")

        results.append(
            {
                "source": source or source_from_title(getattr(item, "title", "")),
                "title": getattr(item, "title", ""),
                "link": getattr(item, "link", ""),
                "published": getattr(item, "published", ""),
            }
        )

    return results


# %% [markdown]
# # Step 2 - Google URL Decoder
#
# Converts Google News redirect URLs into original publisher URLs.

# %%
def decode_google_url(google_url: str) -> Dict[str, object]:
    if gnewsdecoder is None:
        return {
            "status": False,
            "decoded_url": "",
            "error": "googlenewsdecoder is not installed",
        }

    try:
        decoded = gnewsdecoder(google_url)

        if isinstance(decoded, dict):
            return {
                "status": bool(decoded.get("status", False)),
                "decoded_url": decoded.get("decoded_url", "") or decoded.get("url", ""),
                "raw": decoded,
            }

        return {
            "status": bool(decoded),
            "decoded_url": str(decoded),
            "raw": decoded,
        }

    except Exception as exc:
        return {
            "status": False,
            "decoded_url": "",
            "error": str(exc),
        }


def decode_google_results(results: Iterable[Dict[str, str]]) -> List[Dict[str, object]]:
    decoded_results = []

    for result in results:
        decoded = decode_google_url(result["link"])
        decoded_results.append(
            {
                **result,
                "google_link": result["link"],
                "real_url": decoded,
            }
        )

    return decoded_results


# %% [markdown]
# # Step 3 - Semantic Article Ranking
#
# Ranks decoded article titles by semantic similarity to the claim query.

# %%
def rerank_results(
    query: str,
    decoded_results: List[Dict[str, object]],
    semantic_model=None,
) -> List[Dict[str, object]]:
    semantic_model = semantic_model or get_semantic_model()

    valid_results = [
        item
        for item in decoded_results
        if item.get("real_url", {}).get("status")
        and item.get("real_url", {}).get("decoded_url")
    ]

    if not valid_results:
        return []

    titles = [item["title"] for item in valid_results]
    query_embedding = semantic_model.encode(query, convert_to_tensor=True)
    title_embeddings = semantic_model.encode(titles, convert_to_tensor=True)
    scores = util.cos_sim(query_embedding, title_embeddings)[0]

    ranked = []

    for item, score in zip(valid_results, scores):
        ranked.append(
            {
                **item,
                "similarity": float(score.item()),
            }
        )

    ranked.sort(key=lambda x: x["similarity"], reverse=True)
    return ranked


# %% [markdown]
# # Step 4 - Smart Downloader
#
# Downloads article text using newspaper3k first, then trafilatura as fallback.

# %%
def newspaper_extract(url: str, min_chars: int = 500) -> Optional[Dict[str, str]]:
    try:
        article = Article(url, language="en")
        article.download()
        article.parse()

        text = article.text.strip()

        if len(text) >= min_chars:
            return {
                "success": True,
                "method": "newspaper",
                "text": text,
                "title": article.title,
            }

    except Exception:
        pass

    return None


# %% [markdown]
# # Trafilatura Extractor

# %%
def trafilatura_extract(url: str, min_chars: int = 500) -> Optional[Dict[str, str]]:
    if trafilatura is None:
        return None

    try:
        downloaded = trafilatura.fetch_url(url)

        if downloaded is None:
            return None

        text = trafilatura.extract(
            downloaded,
            include_comments=False,
            include_tables=False,
        )

        if text and len(text.strip()) >= min_chars:
            return {
                "success": True,
                "method": "trafilatura",
                "text": text.strip(),
                "title": "",
            }

    except Exception:
        pass

    return None


# %% [markdown]
# # Smart Download Function

# %%
def smart_download(url: str, min_chars: int = 500) -> Dict[str, object]:
    result = newspaper_extract(url, min_chars=min_chars)

    if result:
        return result

    result = trafilatura_extract(url, min_chars=min_chars)

    if result:
        return result

    return {
        "success": False,
        "method": "none",
        "text": "",
        "title": "",
    }


# %% [markdown]
# # Step 5 - Paragraph Extraction
#
# Splits downloaded articles into meaningful evidence paragraphs.

# %%
def split_paragraphs(
    text: str,
    min_chars: int = 80,
    max_chars: int = 1500,
) -> List[str]:
    paragraphs = []

    for paragraph in re.split(r"\n\s*\n", text):
        paragraph = " ".join(paragraph.split())

        if len(paragraph) < min_chars:
            continue

        if len(paragraph) > max_chars:
            paragraph = paragraph[:max_chars].rsplit(" ", 1)[0]

        paragraphs.append(paragraph)

    return paragraphs


# %% [markdown]
# # Step 6 - Paragraph Ranking
#
# Ranks every candidate paragraph against the claim query using MiniLM
# embeddings.

# %%
def rank_pool(
    query: str,
    paragraph_pool: List[Dict[str, object]],
    semantic_model=None,
) -> List[Dict[str, object]]:
    semantic_model = semantic_model or get_semantic_model()

    if not paragraph_pool:
        return []

    paragraphs = [item["paragraph"] for item in paragraph_pool]
    query_embedding = semantic_model.encode(query, convert_to_tensor=True)
    paragraph_embeddings = semantic_model.encode(paragraphs, convert_to_tensor=True)
    scores = util.cos_sim(query_embedding, paragraph_embeddings)[0]

    ranked = []

    for item, score in zip(paragraph_pool, scores):
        ranked.append(
            {
                **item,
                "similarity": float(score.item()),
            }
        )

    ranked.sort(key=lambda x: x["similarity"], reverse=True)
    return ranked


# %% [markdown]
# # Step 7 - Evidence Aggregator
#
# Builds the evidence document passed into the NLI verifier.

# %%
def build_evidence_document(
    ranked_pool: List[Dict[str, object]],
    top_k: int = 5,
) -> str:
    evidence_blocks = []
    used_sources = set()

    for item in ranked_pool:
        source = item.get("source", "Unknown Source")

        if source in used_sources:
            continue

        evidence_blocks.append(
            "\n".join(
                [
                    "SOURCE:",
                    str(source),
                    "",
                    "URL:",
                    str(item.get("url", "")),
                    "",
                    "EVIDENCE:",
                    str(item.get("paragraph", "")),
                ]
            )
        )

        used_sources.add(source)

        if len(evidence_blocks) == top_k:
            break

    return "\n\n".join(evidence_blocks)


# %% [markdown]
# # Source Helpers
#
# Normalizes publisher names and maps sources to credibility scores.

# %%
def source_from_title(title: str) -> str:
    if " - " in title:
        return title.rsplit(" - ", 1)[-1].strip()

    return ""


def domain_from_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower()

    if host.startswith("www."):
        host = host[4:]

    return host


def normalize_source_name(source: str, url: str = "") -> str:
    source = (source or "").strip()

    if source:
        return source

    domain = domain_from_url(url)

    if not domain:
        return "Unknown Source"

    return domain.split(".")[0].replace("-", " ").title()


def credibility_for_source(source: str, url: str = "") -> float:
    text = " ".join([source or "", domain_from_url(url)]).lower()

    for name, weight in SOURCE_CREDIBILITY.items():
        if name in text:
            return weight

    return 0.70


# %% [markdown]
# # Evidence Metrics
#
# Combines paragraph similarity and source credibility into retrieval confidence
# signals used by the final credibility score.

# %%
def evidence_metrics(evidence_items: List[Dict[str, object]]) -> Dict[str, float]:
    if not evidence_items:
        return {
            "evidence_confidence": 0.0,
            "source_credibility": 0.0,
        }

    similarities = [
        max(0.0, min(float(item.get("similarity", 0.0)), 1.0))
        for item in evidence_items
    ]

    source_scores = []

    for item, similarity in zip(evidence_items, similarities):
        source_score = credibility_for_source(
            str(item.get("source", "")),
            str(item.get("url", "")),
        )
        source_scores.append(source_score * similarity)

    return {
        "evidence_confidence": float(sum(similarities) / len(similarities)),
        "source_credibility": float(sum(source_scores) / len(source_scores)),
    }


# %% [markdown]
# # Complete Retrieval Pipeline
#
# Main function called by the fake news prototype for each extracted claim.

# %%
def retrieve_evidence(
    query: str,
    headline: str = "",
    article_text: str = "",
    semantic_model=None,
    config: Optional[RetrievalConfig] = None,
) -> Dict[str, object]:
    config = config or RetrievalConfig()
    semantic_model = semantic_model or get_semantic_model()
    search_query = build_retrieval_query(
        query,
        headline=headline,
        article_text=article_text,
        keyword_count=config.query_keyword_count,
    )

    rss_results = google_news(search_query, max_results=config.rss_results)
    decoded_results = decode_google_results(rss_results)
    ranked_articles = rerank_results(
        search_query,
        decoded_results,
        semantic_model=semantic_model,
    )

    evidence_articles = []

    for article in ranked_articles[: config.ranked_articles]:
        url = article["real_url"]["decoded_url"]
        downloaded = smart_download(url, min_chars=config.min_article_chars)

        if not downloaded["success"]:
            continue

        source = normalize_source_name(
            str(article.get("source", "")) or source_from_title(str(article.get("title", ""))),
            url,
        )

        evidence_articles.append(
            {
                "source": source,
                "title": article["title"],
                "url": url,
                "article_similarity": article["similarity"],
                "text": downloaded["text"],
                "method": downloaded["method"],
            }
        )

        if len(evidence_articles) == config.max_downloads:
            break

    paragraph_pool = []
    per_article_limit = max(
        1,
        config.max_paragraph_pool // max(len(evidence_articles), 1),
    )

    for article in evidence_articles:
        paragraphs = split_paragraphs(
            article["text"],
            min_chars=config.min_paragraph_chars,
            max_chars=config.max_paragraph_chars,
        )

        for paragraph in paragraphs[:per_article_limit]:
            paragraph_pool.append(
                {
                    "source": article["source"],
                    "title": article["title"],
                    "url": article["url"],
                    "paragraph": paragraph,
                    "article_similarity": article["article_similarity"],
                    "method": article["method"],
                }
            )

    ranked_pool = rank_pool(search_query, paragraph_pool, semantic_model=semantic_model)
    top_evidence = []
    used_sources = set()

    for item in ranked_pool:
        if item["source"] in used_sources:
            continue

        top_evidence.append(item)
        used_sources.add(item["source"])

        if len(top_evidence) == config.evidence_paragraphs:
            break

    metrics = evidence_metrics(top_evidence)

    return {
        "query": query,
        "search_query": search_query,
        "rss_results": rss_results,
        "decoded_results": decoded_results,
        "ranked_articles": ranked_articles,
        "downloaded_articles": evidence_articles,
        "ranked_paragraphs": ranked_pool,
        "evidence_items": top_evidence,
        "evidence_document": build_evidence_document(
            top_evidence,
            top_k=config.evidence_paragraphs,
        ),
        **metrics,
    }
