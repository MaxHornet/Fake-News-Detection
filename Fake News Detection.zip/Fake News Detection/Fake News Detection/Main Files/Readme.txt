1. Complete the training process to create the required model files for infererence.

2. Open fakenews_prototype6 ipynb collab file with the same google account to load the trained models.

3. Connect collab runtime to T4 GPU , and dont run it immediately.

4. Upload the retrieval_engine.py and webscrape.py modules to the collab runtime root directory.

5. After that run all cells sequentially.