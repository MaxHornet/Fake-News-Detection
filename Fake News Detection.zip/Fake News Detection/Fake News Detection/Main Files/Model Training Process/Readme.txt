1. Create a folder Named "FakeNews" inside google drive root directory. 

2. Inside FakeNews folder upload this WELFAKE dataset.

3. Then run the collab ipynb file through the same google drive account and run all one by one.