# -*- coding: utf-8 -*-
# %% [markdown]
# # Web Scrape Module
#
# Scrapes URL articles, accepts pasted article text, extracts PDF text, and
# generates categorized summaries for the fake news dashboard.

# %% [markdown]
# # Imports

# %%
import re
from collections import defaultdict
from pathlib import Path

import pandas as pd
from newspaper import Article
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None


# %% [markdown]
# # Category Tree
#
# Keyword taxonomy used to assign category and subcategory labels.

# %%
CATEGORY_TREE = {
    "Technology": {
        "Mobile Phones": [
            "smartphone",
            "mobile",
            "android",
            "iphone",
            "samsung",
            "xiaomi",
            "oneplus",
            "pixel",
            "ios",
            "camera",
            "battery",
            "display",
            "processor",
            "chipset",
            "snapdragon",
            "mediatek",
            "galaxy",
            "fold",
            "flip",
        ],
        "Artificial Intelligence": [
            "ai",
            "artificial",
            "intelligence",
            "llm",
            "chatgpt",
            "openai",
            "gpt",
            "gemini",
            "claude",
            "machine",
            "learning",
            "neural",
            "deep",
        ],
        "Cybersecurity": [
            "hack",
            "hacker",
            "malware",
            "phishing",
            "security",
            "cyber",
            "ransomware",
            "breach",
            "exploit",
        ],
        "Software": [
            "software",
            "application",
            "developer",
            "programming",
            "python",
            "java",
            "javascript",
            "github",
            "api",
            "framework",
        ],
    },
    "Sports": {
        "Cricket": [
            "cricket",
            "batsman",
            "bowler",
            "wicket",
            "ipl",
            "odi",
            "test",
            "century",
            "run",
        ],
        "Football": [
            "football",
            "soccer",
            "goal",
            "fifa",
            "league",
            "premier",
            "club",
        ],
        "Tennis": [
            "tennis",
            "atp",
            "grand",
            "slam",
            "wimbledon",
        ],
    },
    "Politics": {
        "Election": [
            "election",
            "vote",
            "candidate",
            "campaign",
            "poll",
            "voter",
        ],
        "Government": [
            "government",
            "minister",
            "parliament",
            "cabinet",
            "policy",
            "law",
        ],
    },
    "Business": {
        "Stock Market": [
            "stock",
            "market",
            "share",
            "investor",
            "equity",
            "trading",
        ],
        "Economy": [
            "economy",
            "gdp",
            "inflation",
            "bank",
            "interest",
            "reserve",
        ],
        "Startup": [
            "startup",
            "founder",
            "funding",
            "venture",
            "capital",
            "valuation",
        ],
    },
    "Health": {
        "Medicine": [
            "hospital",
            "doctor",
            "patient",
            "disease",
            "treatment",
            "medicine",
        ],
        "Fitness": [
            "fitness",
            "exercise",
            "workout",
            "nutrition",
            "diet",
        ],
    },
    "Gaming": {
        "Video Games": [
            "game",
            "gaming",
            "player",
            "ubisoft",
            "assassin",
            "creed",
            "playstation",
            "xbox",
            "nintendo",
            "steam",
        ],
    },
    "Entertainment": {
        "Movies": [
            "movie",
            "film",
            "actor",
            "director",
            "cinema",
            "boxoffice",
        ],
        "Music": [
            "music",
            "song",
            "album",
            "singer",
            "concert",
        ],
    },
}


# %% [markdown]
# # Text Cleaning

# %%
def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z ]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_title(title, fallback="Untitled Article"):
    title = " ".join(str(title or "").split())
    return title or fallback


# %% [markdown]
# # TF-IDF Keywords
#
# Extracts per-article TF-IDF keywords used by the category classifier.

# %%
def get_article_tfidf_keywords(document_text, top_n=15):
    cleaned = clean_text(document_text)

    if not cleaned:
        return []

    vectorizer = TfidfVectorizer(
        max_features=1000,
        stop_words="english",
    )

    try:
        values = vectorizer.fit_transform([cleaned])
    except ValueError:
        return []

    words = vectorizer.get_feature_names_out()
    scores = values.toarray()[0]
    tfidf_pairs = list(zip(words, scores))
    tfidf_pairs.sort(key=lambda x: x[1], reverse=True)

    return [word for word, score in tfidf_pairs[:top_n]]


# %% [markdown]
# # Category Classifier
#
# Assigns a category and subcategory from the TF-IDF keywords.

# %%
def classify_article(article_keywords):
    category_scores = defaultdict(int)
    subcategory_scores = defaultdict(int)

    for category, subcats in CATEGORY_TREE.items():
        for subcat, keywords in subcats.items():
            score = 0

            for word in article_keywords:
                if word.lower() in keywords:
                    score += 5

            category_scores[category] += score
            subcategory_scores[(category, subcat)] += score

    if max(category_scores.values(), default=0) == 0:
        return "Other", "Uncategorized", {}

    best_category = max(category_scores, key=category_scores.get)
    best_subcategory = max(
        [key for key in subcategory_scores if key[0] == best_category],
        key=lambda key: subcategory_scores[key],
    )

    return best_category, best_subcategory[1], dict(category_scores)


# %% [markdown]
# # Compact Article Summary
#
# Generates a short extractive summary from raw article text.

# %%
def generate_summary(text, top_n=5):
    sentences = sent_tokenize(text)

    if len(sentences) <= top_n:
        return text

    word_scores = {}
    words = word_tokenize(text.lower())

    for word in words:
        if word.isalpha():
            word_scores[word] = word_scores.get(word, 0) + 1

    sentence_scores = {}

    for sentence in sentences:
        score = 0
        sentence_words = word_tokenize(sentence.lower())

        for word in sentence_words:
            score += word_scores.get(word, 0)

        sentence_scores[sentence] = score

    ranked = sorted(
        sentence_scores,
        key=sentence_scores.get,
        reverse=True,
    )

    return " ".join(ranked[:top_n])


# %% [markdown]
# # URL Scraper
#
# Scrapes raw article title and text from a URL using newspaper3k.

# %%
def scrape_url(url):
    article = Article(url)
    article.download()
    article.parse()

    return {
        "input_type": "url",
        "source": url,
        "url": url,
        "title": normalize_title(article.title),
        "text": article.text.strip(),
        "authors": article.authors,
        "publish_date": str(article.publish_date or ""),
        "top_image": article.top_image,
        "scrape_status": "success",
        "scrape_error": "",
    }


# %% [markdown]
# # Text Input Parser
#
# Accepts pasted article text. The first non-empty line is used as a fallback
# title when no explicit title is provided.

# %%
def article_from_text(text, title=""):
    text = text.strip()
    fallback_title = text.splitlines()[0][:120] if text else "Pasted Article"

    return {
        "input_type": "text",
        "source": "manual_text",
        "url": "",
        "title": normalize_title(title, fallback=fallback_title),
        "text": text,
        "authors": [],
        "publish_date": "",
        "top_image": "",
        "scrape_status": "success",
        "scrape_error": "",
    }


# %% [markdown]
# # PDF Text Extractor
#
# Extracts raw text from a local PDF path using pypdf.

# %%
def extract_pdf_text(pdf_path):
    if PdfReader is None:
        raise ImportError("pypdf is not installed. Run: !pip -q install pypdf")

    reader = PdfReader(str(pdf_path))
    pages = []

    for page in reader.pages:
        pages.append(page.extract_text() or "")

    return "\n\n".join(pages).strip()


def article_from_pdf(pdf_path, title=""):
    pdf_path = Path(pdf_path)
    text = extract_pdf_text(pdf_path)

    return {
        "input_type": "pdf",
        "source": str(pdf_path),
        "url": "",
        "title": normalize_title(title, fallback=pdf_path.stem),
        "text": text,
        "authors": [],
        "publish_date": "",
        "top_image": "",
        "scrape_status": "success",
        "scrape_error": "",
    }


# %% [markdown]
# # Categorized Summary
#
# Adds clean text, TF-IDF keywords, category, subcategory, score map, and summary
# to each scraped article.

# %%
def enrich_article(article, summary_sentences=5):
    text = article.get("text", "")
    keywords = get_article_tfidf_keywords(text)
    category, subcategory, scores = classify_article(keywords)

    return {
        **article,
        "clean_text": clean_text(text),
        "tfidf_keywords": keywords,
        "category": category,
        "subcategory": subcategory,
        "category_scores": scores,
        "summary": generate_summary(text, top_n=summary_sentences) if text else "",
    }


def build_dataframe(articles, min_chars=200):
    rows = []

    for article in articles:
        if len(article.get("text", "")) < min_chars:
            rows.append(
                {
                    **article,
                    "scrape_status": "skipped",
                    "scrape_error": "Text is too short",
                }
            )
            continue

        rows.append(enrich_article(article))

    return pd.DataFrame(rows)


# %% [markdown]
# # Interactive Input
#
# Supports URL, pasted text, and PDF path inputs.

# %%
def collect_article_inputs():
    print("Choose input type:")
    print("1. URL")
    print("2. Text")
    print("3. PDF")
    print("Press ENTER on input type when finished.\n")

    articles = []

    while True:
        input_type = input("Input type (url/text/pdf or 1/2/3): ").strip().lower()

        if input_type == "":
            break

        if input_type in {"1", "url", "u"}:
            url = input("URL: ").strip()

            if not url:
                continue

            try:
                article = scrape_url(url)
                print("SUCCESS:", article["title"])
            except Exception as exc:
                print("FAILED:", url)
                print(exc)
                article = {
                    "input_type": "url",
                    "source": url,
                    "url": url,
                    "title": "",
                    "text": "",
                    "authors": [],
                    "publish_date": "",
                    "top_image": "",
                    "scrape_status": "failed",
                    "scrape_error": str(exc),
                }

            articles.append(article)

        elif input_type in {"2", "text", "t"}:
            title = input("Optional title/headline: ").strip()
            print("Paste article text. Press ENTER on an empty line when finished.")

            lines = []

            while True:
                line = input()

                if line == "":
                    break

                lines.append(line)

            article = article_from_text("\n".join(lines), title=title)
            print("TEXT CAPTURED:", article["title"])
            articles.append(article)

        elif input_type in {"3", "pdf", "p"}:
            pdf_path = input("PDF path: ").strip()
            title = input("Optional title/headline: ").strip()

            if not pdf_path:
                continue

            try:
                article = article_from_pdf(pdf_path, title=title)
                print("PDF TEXT EXTRACTED:", article["title"])
            except Exception as exc:
                print("FAILED:", pdf_path)
                print(exc)
                article = {
                    "input_type": "pdf",
                    "source": pdf_path,
                    "url": "",
                    "title": title,
                    "text": "",
                    "authors": [],
                    "publish_date": "",
                    "top_image": "",
                    "scrape_status": "failed",
                    "scrape_error": str(exc),
                }

            articles.append(article)

        else:
            print("Unknown input type. Use url, text, or pdf.")

    df = build_dataframe(articles)
    successful = df[df["scrape_status"] == "success"] if not df.empty else df

    print(f"\nInputs captured: {len(df)}")
    print(f"Successfully prepared: {len(successful)}")

    return df
